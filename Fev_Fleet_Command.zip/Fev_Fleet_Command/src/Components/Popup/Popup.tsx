import React, { ReactNode } from 'react';
import './Popup.css'
type PopupProps = {
    isOpen: boolean;
    onClose: () => void;
    children: ReactNode;
    key: React.Key;
  };

const Popup: React.FC<PopupProps> = ({isOpen, onClose, children}) => {
    if (!isOpen) {
        return null; // Don't render anything if the popup is closed
      }
      return (
        <div >
          <div className="popup">
            <div className='popup-inner'>
            <span className='las la-times' onClick={onClose}></span>
            {children}
            </div>
          </div>
        </div>
      );
};

export default Popup;
