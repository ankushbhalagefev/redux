// import * as React from "react";
// import MyMapp, {
//   Marker,
//   NavigationControl,
//   FullscreenControl,
//   GeolocateControl,
// } from "react-map-gl";

// import "mapbox-gl/dist/mapbox-gl.css";
// import "./Map.css";

// const MyMap = ({ width, height }) => {

//   const geolocateControlStyle = {
//     left: 10,
//     top: 10,
//    };

//    const fullscreenControlStyle = {
//     right: 10,
//     top: 10,
//    };

//   const [viewState, setViewState] = React.useState({
//     latitude: 18.5204,
//     longitude: 73.8567,
//     zoom: 14,
//   });

//   const marker = {
//     latitude: 18.5204,
//     longitude: 73.8567,
//   };

//   const navControlStyle = {
//     right: 10,
//     bottom: 10,
//   };

//   return (
//     <div className="map">
//       <MyMapp
//         {...viewState}
//         onMove={(evt) => setViewState(evt.viewState)}
//         style={{width, height}}
//         mapStyle="mapbox://styles/mapbox/streets-v9"
//         mapboxAccessToken={process.env.REACT_APP_MAPBOX_TOKEN}
//         transitionDuration={2000}
//         // transitionInterpolator={new FlyToInterpolator()}
//       >

// <FullscreenControl style={fullscreenControlStyle} />
//        <GeolocateControl
//          style={geolocateControlStyle}
//          positionOptions={{ enableHighAccuracy: true }}
//          trackUserLocation={true}
//          auto={false}
//        />
//         <Marker
//           longitude={marker.longitude}
//           latitude={marker.latitude}
//           color="black"
//           offsetLeft={200}
//           offsetTop={10}
//         />
//         <NavigationControl
//           style={navControlStyle}
//           showCompass={true}
//           showZoom={true}
//         />
//       </MyMapp>
//     </div>
//   );
// };

// export default MyMap;



import React from "react";
import MyMapp, {
  Marker,
  NavigationControl,
  FullscreenControl,
  GeolocateControl,
} from "react-map-gl";

import "mapbox-gl/dist/mapbox-gl.css";

const MyMap = ({ width, height, markers }) => {
  const geolocateControlStyle = {
    left: 10,
    top: 10,
  };

  const fullscreenControlStyle = {
    right: 10,
    top: 10,
  };

  const [viewState, setViewState] = React.useState({
    latitude: 18.5204,
    longitude: 73.8567,
    zoom: 14,
  });

  const navControlStyle = {
    right: 10,
    bottom: 10,
  };

  return (
    <div className="map">
      <MyMapp
        {...viewState}
        onMove={(evt) => setViewState(evt.viewState)}
        style={{ width, height }}
        mapStyle="mapbox://styles/mapbox/streets-v9"
        mapboxAccessToken={process.env.REACT_APP_MAPBOX_TOKEN}
        transitionDuration={2000}
      >
        <FullscreenControl style={fullscreenControlStyle} />
        <GeolocateControl
          style={geolocateControlStyle}
          positionOptions={{ enableHighAccuracy: true }}
          trackUserLocation={true}
          auto={false}
        />
        {markers.map((marker, index) => (
          <Marker
            key={index}
            longitude={marker.longitude}
            latitude={marker.latitude}
            color="black"
            offsetLeft={200}
            offsetTop={10}>
          <img className="marker" src="car2.png"></img>             
            </Marker>
          
        ))}
        <NavigationControl style={navControlStyle} showCompass={true} showZoom={true} />
      </MyMapp>
    </div>
  );
};

export default MyMap;
