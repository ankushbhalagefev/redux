import React from 'react'
import './Footer.css'
import logo from '../../assets/images/Group 33443 (2).png'
const Footer = () => {
  return (
    <div className='footer_container'>
      <div className='footer_text'><h4>&copy; 2023 FEV India. All rights reserved.</h4></div>
      <div className='footer_logo'><img src={logo} alt='fevlogo'/></div>
      
    </div>
  )
}

export default Footer