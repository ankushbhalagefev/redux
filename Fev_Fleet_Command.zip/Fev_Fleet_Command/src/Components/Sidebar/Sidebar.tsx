import React from 'react'
import './Sidebar.css'
import { Link } from 'react-router-dom'
const Sidebar = () => {
  return (
    <div className='sidebar_container'>
        <div className='menu_bar'>
          
          <ul>
         
          <li>General</li>
            <li><Link to="/dashboard"><span className="lab la-buffer"></span> Dashboard</Link></li>
            <li><Link to="/users"><span className='las la-users'></span> Users</Link></li>
            <li><Link to="/vehicle"><span className='las la-truck'></span> Vehicle</Link></li>
          </ul>
        </div>
        <div className='menu_bar'>
          
          <ul>
          
          <li>Fleet Management</li>
            <li><Link to ="/fleet"><span className='las la-truck'></span> Fleet</Link></li>
            <li><Link to="/products"><span className='lab la-product-hunt'></span> Products</Link></li>
            <li><Link to="/variant"><span className="las la-gas-pump"></span> Variants</Link></li>
            <li><Link to="/model"><span className='las la-car-side'></span> Model</Link></li>
            <li><Link to="/ota"><span className='las la-truck'></span> ota</Link></li>
            <li><Link to="/pki"><span className='las la-key'></span>pki</Link></li>
          </ul>
        </div>
        <div className='menu_bar'>
          
          <ul>
          
          <li>Driver Management</li>
            <li><Link to="map"><span className='las la-map-marker'></span> map</Link></li>
            <li><Link to="/"><span className='las la-truck'></span> fatigue risk</Link></li>
            <li><Link to="/"><span className='las la-calendar-check'></span> events</Link></li>
            <li><Link to="/"><span className='las la-truck'></span> vehicle contact</Link></li>
          </ul>
        </div>
    </div>
  )
}

export default Sidebar