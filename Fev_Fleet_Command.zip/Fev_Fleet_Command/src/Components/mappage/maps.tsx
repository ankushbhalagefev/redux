import { Fragment, useState } from "react";
import Map from "../Map/Map";
import Header from '../Header/Header';
import Sidebar from '../Sidebar/Sidebar';
import Footer from '../Footer/Footer';
import './maps.css';

const Maps = () => {
    return (
        <><Header/><Sidebar/>
        <Fragment>
            <div className="container">
            <div className="container-center">
        <div className="container-right">
            <div className="map-text">
                <div className="top-map-box">
                <h3>Map</h3>
                </div>
                <div className="map-text-option">
                    <div className="acceleration">Acceleration</div>
                    <div className="acceleration" style={{backgroundColor:"greenyellow"}}>Cell Phone</div>
                    <div className="acceleration" style={{backgroundColor:"red"}}>Attention Off Road</div>
                    <div className="acceleration" style={{backgroundColor:"pink "}}>Fatigue</div>
                    <div className="acceleration" style={{backgroundColor:"orange"}}>FOV Exception</div>
                    <div className="acceleration" style={{backgroundColor:"blue"}}>Manual Recording</div>
                    <div className="acceleration" style={{backgroundColor:"green"}}>Manual Recording</div>
                    <div className="acceleration" style={{backgroundColor:"skyblue"}}>Overspeed</div>
                </div>
                <div className="dropdown">
                <select className="select">
                    <option className="option" value="">Last hour</option>
                    <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option>
                </select>
                    <h4>Showing 29 of 29</h4>
                </div>
              
            </div>
        <div className="container-map">
        <Map width="1570px" height="600px"  markers={[
    { latitude: 18.5204, longitude: 73.8567 },
    { latitude: 18.6304, longitude: 73.8457 },
    { latitude: 18.1404, longitude: 73.8347 },
    { latitude: 18.3504, longitude: 73.8297 },
    { latitude: 18.5604, longitude: 73.8117 },
    { latitude: 18.5704, longitude: 73.8037 },
    { latitude: 18.5804, longitude: 73.8687 },
    // Add more markers as needed
  ]}/>
        </div>
        </div>
        </div>
        
        </div>
        </Fragment></>
    )

}
export default Maps


