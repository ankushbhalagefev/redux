import React, { useState, useEffect, useRef } from 'react';
import './Header.css';
import { useNavigate } from 'react-router-dom';
import Fleet_command_logo from '../../assets/images/Feet_command_logo.png'
const Header = () => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement | null>(null);
  const navigate=useNavigate();
  // Function to handle clicks outside the profile div
  const handleClickOutside = (event: MouseEvent) => {
    if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
      setIsProfileOpen(false);
    }
  };

  // Attach an event listener to the document to handle clicks outside the profile div
  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const logout=()=>{
    sessionStorage.clear();
    navigate('/login');
    window.location.reload();
  }

  return (
    <div className='header_container'>
      <div className='logo'>
        <img src={Fleet_command_logo} alt='fleet_command logo' />
      </div>
      <div className='profile'onClick={() => setIsProfileOpen(!isProfileOpen)} ref={profileRef}>
        <span className='las la-user-circle' ></span><span>FEV_SUPER_USER</span>
        {isProfileOpen && (
          <div className='profile-dropdown'>
            <ul>
              <li onClick={()=>navigate("/profile")}>Profile</li>
              <li onClick={logout}>Logout</li>
            </ul>
          </div>
        )}
        
      </div>
    </div>
  );
};

export default Header;
