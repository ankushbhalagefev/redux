import { useState } from "react"
import { useNavigate } from "react-router-dom";

const Auth=()=>{
    const navigate=useNavigate();
    const getToken=():string | null =>{
        const tokenstring=sessionStorage.getItem('token');
        if(tokenstring){
            try {
                const userToken=JSON.parse(tokenstring) as string;
                return userToken;
            } catch (error) {
                console.log("Error in parsing token",error);
                return null;
            }

        }
        return null;
    };
            
    const saveToken=(token:string)=>{
         sessionStorage.setItem("token",JSON.stringify(token));
         setToken(token);
         navigate("/dashboard");
    }
    const [token,setToken]=useState<string | null>(getToken());
    return {
      setToken:saveToken,token,getToken
    }
}
export default Auth;