import * as Yup from 'yup';

export const addUserSchema: Yup.ObjectSchema<object> = Yup.object().shape({
    first_name: Yup.string().min(2).max(25).required('Please enter your first name'),    
  last_name: Yup.string().min(2).max(25).required('Please enter your last name'),
  email: Yup.string().email().required('Please enter your email'),
});
export const loginSchema:Yup.ObjectSchema<object>=Yup.object().shape({
  email: Yup.string().email().required('Please enter your email'),
  password: Yup.string()
    .min(8, 'Password must be at least 8 characters long')
    .matches(/[A-Z]/, 'Password must contain at least 1 uppercase letter')
    .matches(/\d/, 'Password must contain at least 1 digit')
    .matches(/[!@#$%^&*(),.?":{}|<>]/, 'Password must contain at least 1 special character')
    .required('Please enter your password')
})
export const resetPasswordSchema:Yup.ObjectSchema<object>=Yup.object().shape({
  password: Yup.string()
    .min(8, 'Password must be at least 8 characters long')
    .matches(/[A-Z]/, 'Password must contain at least 1 uppercase letter')
    .matches(/\d/, 'Password must contain at least 1 digit')
    .matches(/[!@#$%^&*(),.?":{}|<>]/, 'Password must contain at least 1 special character')
    .required('Please enter your password'),

  confirm_password: Yup.string()
    .required()
    .oneOf([Yup.ref('password'), ''], 'Password must match'),
})
