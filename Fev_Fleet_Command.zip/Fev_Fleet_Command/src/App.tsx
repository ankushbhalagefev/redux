import React from 'react';
import {Route, Routes } from 'react-router-dom';
import Auth from './Middleware/Auth'; // Import your Auth component
import Login from './Pages/Login/Login';
import Dashboard from './Pages/Dashboard/Dashboard';
import './App.css'
import Forgot_Password from './Pages/forgot password/Forgot_Password';
import Users from './Pages/User/Users';
import UserDetails from './Pages/UserDetails/UserDetail';
import UserProfile from './Pages/UserProfile/UserProfile';
import Vehicle from './Pages/Vehicle/Vehicle';
import Map from './Components/mappage/maps'
import Reset_password from './Pages/Reset Password/Reset_password';
import ResendInvitation from './Pages/ResendInvitation/ResendInvitation';
import VehicleDetails from './Pages/VehicleDetails/VehicleDetails';
import Fleet from './Pages/Fleet/Fleet';
import Products from './Pages/Products/Products';
import Pki from './Pages/PKI/Pki';
import Header from './Components/Header/Header';
import Sidebar from './Components/Sidebar/Sidebar';
import Footer from './Components/Footer/Footer';
import Ota from './Pages/Ota/Ota';
import Model from './Pages/Model/Model';
import Variants from './Pages/Variants/Variants';
const App: React.FC = () => {
  const { getToken } = Auth();



  if (!getToken()) {
    return (<>
    <Header/>
      <Sidebar/>
     
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/login" element={<Login />} />
      <Route path='/forgot_password' element={<Forgot_Password/>}/>
            <Route path="/reset_password" element={<Reset_password/>} />
            <Route path="/resend_invitation" element={<ResendInvitation />} /> 
            <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/map" element={<Map />} />
        <Route path="/users" element={<Users />} />
        <Route path="/users/:userId" element={<UserDetails />} />
        <Route path="/profile" element={<UserProfile />} />
        <Route path='/vehicle' element={<Vehicle />} />
        <Route path='/vehicle/:vehicleId' element={<VehicleDetails />} />
        <Route path='/profile' element={<UserProfile />} />
        <Route path='/fleet' element={<Fleet/>}/>
        <Route path='/products' element={<Products/>}/>
        <Route path='pki' element={<Pki/>}/>
        <Route path='ota' element={<Ota/>}/>
        <Route path='model' element={<Model/>} />
        <Route path='variant' element={<Variants/>}/>
    </Routes>
    <Footer/>
    </>
    )
  } else {
    return (
      <>
      <Header/>
      <Sidebar/>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/map" element={<Map />} />
        <Route path="/users" element={<Users />} />
        <Route path="/users/:userId" element={<UserDetails />} />
        <Route path="/profile" element={<UserProfile />} />
        <Route path='/vehicle' element={<Vehicle />} />
        <Route path='/vehicle/:vehicleId' element={<VehicleDetails />} />
        <Route path='/profile' element={<UserProfile />} />
        <Route path='/fleet' element={<Fleet/>}/>
        <Route path='/products' element={<Products/>}/>
        <Route path='pki' element={<Pki/>}/>
        <Route path='ota' element={<Ota/>}/>
      </Routes>
      <Footer/>
      </>
    )
  }



};

export default App;
