import React, { useEffect, useState } from 'react'
import DataTable, { TableColumn } from 'react-data-table-component'
import axios from 'axios'
import Popup from '../../Components/Popup/Popup'
const Products = () => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const openPopup = () => {

    setIsPopupOpen(true);
  };

  const closePopup = () => {
    setIsPopupOpen(false);
  };
  interface product{
    id:number,
    product:string,
    name:string,
    description:string,
    vehicles:string
  }
  const column:TableColumn<product>[]=[{
    name:'Product',
    selector:row=>row.product
  },
{
  name:'Name',
  selector:row=>row.name
},
{
  name:"Description",
  selector:row=>row.description
},
{
  name:"Vehicles",
  selector:row=>row.vehicles
}
]
const [products,setProducts]=useState([]);
useEffect(()=>{
  axios.get("http://localhost:3000/products").then((resp)=>{
    setProducts(resp.data);
  })
},[])
  return (
   <>
      
   <div className='globalContainer'>
        <h3>Products</h3>
        <div className="search-bar">
          <span>
            <input/><i className='lab la-searchengin'></i>
            
          </span>
          <button className='add' onClick={openPopup}><i className='las la-plus'></i>Product</button> 
        </div>
        <div>
          <DataTable
          columns={column}
          data={products}
          responsive={true}
          pagination
          striped
          pointerOnHover
          fixedHeader
          />
        </div>
        <Popup key="product"  isOpen={isPopupOpen} onClose={closePopup}>
           <form className='popup-form'>
            <h3>Add New Product</h3>
             <div className='common_input'>
              <label>Product Family</label>
              <select>
                <option>Select</option>
                <option>BEV</option>
                <option>FCEV</option>
              </select>
             </div>
             <div className='common_input'>
              <label>Name</label>
              <input/>
             </div>
             <div className='description'>
              <label>Description</label>
              <input/>
             </div>
             <div>
              <button>Cancel</button>
              <button>Add Product</button>
             </div>
           </form>
        </Popup>
   </div>
   </>
  )
}

export default Products