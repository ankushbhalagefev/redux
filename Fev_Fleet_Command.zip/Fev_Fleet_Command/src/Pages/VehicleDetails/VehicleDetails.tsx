import React, { useState, Fragment } from "react";
import Map from "../../Components/Map/Map";
import "./VehicleDetails.css";
import Popup from "../../Components/Popup/Popup";
import AssignDrivers from "./AssignDrivers";

const VehicleDetails = () => {

  const [isAssignDriverPopupOpen, setIsAssignDriverPopupOpen] = useState(false);

  const assignDriverOpenPopup = () => {
    setIsAssignDriverPopupOpen(true);
  };

  const assignDriverClosePopup = () => {
    setIsAssignDriverPopupOpen(false);
  };

  const [transferredDrivers, setTransferredDrivers] = useState<any[]>([]);

  const [drivers, setDrivers] = useState<any[]>([
    { name: "Driver 1", selected: false },
    { name: "Driver 2", selected: false },
    { name: "Driver 3", selected: false },
    { name: "Driver 4", selected: false },
    { name: "Driver 5", selected: false },
    { name: "Driver 6", selected: false },
    // // Add more drivers as needed
  ]);

  const handleCheckboxChange = (index: number) => {
    const updatedDrivers = [...drivers];
    updatedDrivers[index] = {
      ...updatedDrivers[index],
      selected: !updatedDrivers[index].selected,
    };
    setDrivers(updatedDrivers);
  };

  const handleTransferredCheckboxChange = (index: number) => {
    const updatedTransferredDrivers = [...transferredDrivers];
    updatedTransferredDrivers[index] = {
      ...updatedTransferredDrivers[index],
      selected: !updatedTransferredDrivers[index].selected,
    };
    setTransferredDrivers(updatedTransferredDrivers);
  };

  const handleTransfer = () => {
    const selectedDrivers = drivers.filter((driver) => driver.selected);
    setTransferredDrivers([...transferredDrivers, ...selectedDrivers]);
    setDrivers(drivers.filter((driver) => !driver.selected));
  };

  const handleTransferToAvailable = () => {
    const selectedTransferredDrivers = transferredDrivers.filter(
      (driver) => driver.selected
    );
    setDrivers([...drivers, ...selectedTransferredDrivers]);
    setTransferredDrivers(
      transferredDrivers.filter((driver) => !driver.selected)
    );
  };

  const handleSelectAll = () => {
    const updatedDrivers = drivers.map((driver) => ({
      ...driver,
      selected: true,
    }));
    setDrivers(updatedDrivers);
  };

  const handleSelectAllTransferred = () => {
    const updatedTransferredDrivers = transferredDrivers.map((driver) => ({
      ...driver,
      selected: true,
    }));
    setTransferredDrivers(updatedTransferredDrivers);
  };


  const handleClearAll = () => {
    const updatedDrivers = drivers.map(driver => ({ ...driver, selected: false }));
    setDrivers(updatedDrivers);
  };

  const handleClearAllTransferred = () => {
    const updatedTransferredDrivers = transferredDrivers.map(driver => ({ ...driver, selected: false }));
    setTransferredDrivers(updatedTransferredDrivers);
  };


  return (
    <Fragment>
     
      <div className="vehicle-container">
        <div className="top-container">
          <div className="container-unit-information">
            <div className="vehicle-info">
              <h2>VEHICLE INFORMATION</h2>
            </div>
            <div className="vehicle-name">
              <h4>Vehicle Name</h4>
              <div className="vehicle-input">
                <input
                  type="text"
                  placeholder="Add unit name"
                  id="first_name"
                />
                <span>
                  <i className="las la-save"></i>
                </span>
              </div>
            </div>
            <div className="vehicle-details">
              <div className="vehicle-details-left">
                <span>
                  <h4>VIN:</h4>
                  <h4>FEV-10-487650</h4>
                </span>
                <span>
                  <h4>Product:</h4>
                  <h4>FEV Pre</h4>
                </span>

                <span>
                  <h4>Current Driver:</h4> <h4>FEV Cloud Team</h4>
                </span>
                <span>
                  <h4>H2 Fuel Mass Remaining:</h4>
                  <h4>N/A</h4>
                </span>
                <span>
                  <h4>Fuel:</h4>
                  <h4>80.1</h4>
                  {/* <i className="las la-battery-half"></i> */}
                </span>

                <span>
                  <h4>Odometer:</h4> <h4>0</h4>
                </span>

                <span>
                  <h4>OTA Status:</h4>
                  <h4>0</h4>
                </span>
                <span>
                  <h4>Registration:</h4>
                  <h4>N/A</h4>
                </span>
                <span>
                  <h4>SMS Number:</h4> <h4>318760</h4>
                </span>
              </div>
            </div>
            <div className="vehicle-information-buttons">
              <button className="add">MANAGE FILTERS</button>
              <button className="add">OTA COMPARISON</button>
            </div>
          </div>

          <div className="map-container">
            <Map width="780px" height="900px" markers={[
    { latitude: 18.5204, longitude: 73.8567 },
    
    // Add more markers as needed
    // Add more markers as needed
  ]} />
          </div>
        </div>
        <div className="container-bottom">
          <div className="driver">
            <h2>DRIVERS</h2>
          </div>
          <div className="driver-second-row">
            <div className="search-driver">
              <input
                type="text"
                placeholder="Search for drivers"
                id="first_name"
              />
              <span>
                <i className="las la-search"></i>
              </span>
            </div>
            <div className="driver-button">
              <button className="add" onClick={assignDriverOpenPopup}>
                ASSIGN DRIVER
              </button>
            </div>
          </div>
          <div className="driver-third-row">
            <div className="driver-names">
              <div>
                <h4>Name</h4>
                <span>
                  <i className="las la-arrow-up"></i>
                </span>
              </div>
              <h4>No Drivers Found</h4>
              <h5>Showing 0 of 0</h5>
            </div>
            <div className="assigned-devices">
              <h4>Assigned Vehicles</h4>
            </div>
          </div>
        </div>
        <Popup
          key="User"
          isOpen={isAssignDriverPopupOpen}
          onClose={assignDriverClosePopup}
        >
          <AssignDrivers/>
        </Popup>
      </div>
    </Fragment>
  );
};

export default VehicleDetails;
