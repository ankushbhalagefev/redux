import React, { useEffect, useState } from 'react'

import DataTable, { TableColumn } from 'react-data-table-component'
import { RootState, useAppDispatch } from '../../redux/store'
import { useSelector } from 'react-redux'
import { getAllFleets } from '../../redux/Fleet/FleetApi'
import Popup from '../../Components/Popup/Popup'
const Fleet = () => {
  const dispatch = useAppDispatch();
  const { fleets, fleetLoading } = useSelector((state: RootState) => state.fleetSlice)
  interface DataRow {
    id: number,
    name: string,
    users: number,
    vehicles: number

  }

  const column: TableColumn<DataRow>[] = [
    {
      name: 'Name',
      selector: row => row.name,
    },
    {
      name: 'Users',
      selector: row => row.users
    },
    {
      name: 'Vehicles',
      selector: row => row.vehicles
    }
  ]
  useEffect(() => {
    dispatch(getAllFleets())
  }, [dispatch])

  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const openPopup = () => {

    setIsPopupOpen(true);
  };

  const closePopup = () => {
    setIsPopupOpen(false);
  };

  return (
    <>
      
      <div className='globalContainer'>
        <h3>Fleet</h3>
        <div className='search-bar'>
          <span className='search-bar-span'><input type='search' placeholder='Search for user' /> <i className='lab la-searchengin'></i></span>
          <button className='add' onClick={() => openPopup()}><i className='las la-plus'></i> Fleet</button>
        </div>
        <div className='table-container'>
          <DataTable
            className='datatable_component'
            columns={column}
            data={fleets}
            pointerOnHover
            responsive={true}
            pagination
            fixedHeader
            // onRowClicked={(row: DataRow) => navigate(`${row.id}`)}
            striped

          />
        </div>
        <Popup key="fleet" isOpen={isPopupOpen} onClose={closePopup}>
          <form action="" className="popup-form">
            <h3>Add new Fleet</h3>
            <div className='common_input'>
              <label>Fleet Name</label>
              <input type='text' />
            </div>
            <div>
              <button onClick={() => closePopup()}>Cancel</button>
              <button type='submit'>ADD Fleet</button>
            </div>
          </form>
        </Popup>
      </div>
    </>
  )
}

export default Fleet