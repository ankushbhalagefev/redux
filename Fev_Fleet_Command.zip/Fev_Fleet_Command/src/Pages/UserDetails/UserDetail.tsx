import { Fragment, useEffect, useState } from "react";
import Popup from "../../Components/Popup/Popup";
import "./UserDetails.css";
import Header from "../../Components/Header/Header";
import Sidebar from "../../Components/Sidebar/Sidebar";
import { useParams } from "react-router-dom";
import { RootState, useAppDispatch } from "../../redux/store";
import { getUserById } from "../../redux/User/UsersApi";
import { number } from "echarts";
import { string } from "yup";
import { useSelector } from "react-redux";
import AssignUnits from "./AssignUnits";
import AssignFleet from "./AssignFleet";
import EditUser from "./EditUser";


const UserDetails = () => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [isFleetPopupOpen, setIsFleetPopupOpen] = useState(false);
  const [isUnitPopupOpen, setIsUnitPopupOpen] = useState(false);
  interface RouteParams {
    userId: string; // Define the type of userId
  }
  const { userId } = useParams<{ userId: string }>();
  const dispatch=useAppDispatch();
  const {user} =useSelector((state:RootState)=>state.UsersSlice);

  const editOpenPopup = () => {
    setIsPopupOpen(true);
  };

  const editClosePopup = () => {
    setIsPopupOpen(false);
  };
  
  const fleetOpenPopup = () => {
    setIsFleetPopupOpen(true);
  };

  const fleetClosePopup = () => {
    setIsFleetPopupOpen(false);
  };
  const unitOpenPopup = () => {
    setIsUnitPopupOpen(true);
  };

  const unitClosePopup = () => {
    setIsUnitPopupOpen(false);
  };
useEffect(()=>{

  // console.log("Hello",userId)/
  dispatch(getUserById(Number(userId)))

},[dispatch,userId])
  return (<>
  <Header/>
  <Sidebar/>
    <Fragment>
      <div className="container">
        <div className="first-row">
          <div className="userdetails">
            <div className="user-top">
              <div className="user-text">
                <h1>USER DETAILS</h1>
              </div>
              <div className="button">
                <button onClick={editOpenPopup}>EDIT</button>
              </div>
            </div>
            <div className="user-info">
              <div className="title">
                <h3>Name:</h3>
                <h3>Phone:</h3>
                <h3>Email:</h3>
                <h3>Roles:</h3>
                <h3>Start Date:</h3>
              </div>
              <div className="response">
                <h3>{user.first_name +" "+ user.last_name}</h3>
                <h3>{user.phone}</h3>
                <h3>{user.email}</h3>
                <h3>{user.roles.join(', ')}</h3>
                <h3>September 21, 2023</h3>
              </div>
            </div>
          </div>

          <div className="fleets">
            <div className="fleet-top">
              <div className="user-text">
                <h1>FLEETS</h1>
              </div>
              <div className="button">
                <button onClick={fleetOpenPopup}>ASSIGN FLEET</button>
              </div>
            </div>
            <div className="user-info">
              <div className="fleet-title">
                <h3>Name</h3>
                <h3>FEV-Cloud Team</h3>
                <h3>fev-team</h3>
                <h3>Showing 2 of 2</h3>
              </div>
              <div className="delete">
                <div>
                <img src="delete.png"></img>
                </div>
                <div>
                  <img src="delete.png"></img>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="second-row">
          <div className="unitdetails">
            <div className="unit-top">
              <div className="user-text">
                <h1>UNITS</h1>
              </div>
              <div className="button">
                <button onClick={unitOpenPopup}>ASSIGN UNITS</button>
              </div>
            </div>
            <div className="unit-info">
              <div className="fleet-title">
                <h3>Name</h3>
                <h3>FEV-Cloud Team</h3>
                <h3>fev-team</h3>
                <h3>Showing 2 of 2</h3>
              </div>
              <div className="delete">
                <div>
                  <img src="delete.png"></img>
                </div>
                <div>
                  <img src="delete.png"></img>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Popup key="User" isOpen={isPopupOpen} onClose={editClosePopup}>
         <EditUser/>
        </Popup>
        <Popup key="User1" isOpen={isFleetPopupOpen} onClose={fleetClosePopup}>
          <AssignFleet/>
        </Popup>
        <Popup key="User12" isOpen={isUnitPopupOpen} onClose={unitClosePopup}>
        <AssignUnits/>
        </Popup>
      </div>
    </Fragment>
    </>
  );
};
export default UserDetails;