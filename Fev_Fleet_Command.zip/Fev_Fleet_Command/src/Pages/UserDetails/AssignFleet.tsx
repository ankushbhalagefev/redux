import React, { Fragment } from "react";
import "./AssignFleet.css";
const AssignFleet = () => {
    return (
        <Fragment>
            <div className="assign-fleet">
                <div className="assign-fleet-title">
                    <h2>ASSIGN FLEET</h2>
                </div>
                <div>
                <div className="choose-role">
                    <h3>Choose Role</h3>
                </div>
                <div className="choose-role-checkbox">
                <input type="checkbox" />
                <label htmlFor="vehicle1">Fleet Admin</label>

                <input type="checkbox" />
                <label htmlFor="vehicle1">Driver</label>

                <input type="checkbox" />
                <label htmlFor="vehicle1">Fleet Service Technician</label>
                </div>
                </div>
                <div className="choose-fleet">
                    <div className="choose-fleet-title">
                        <h3>Choose Fleet</h3>
                    </div>
                    <div>

                    </div>
                    </div>
                    <div className="assign-fleet-buttons">
                        <button className="add">CANCEL</button>
                        <button className="add">APPLY</button>
                    </div>
               
            </div> 
        </Fragment>
    )

}

export default AssignFleet;