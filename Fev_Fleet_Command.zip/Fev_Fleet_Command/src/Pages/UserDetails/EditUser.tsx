import React, { Fragment } from "react";

import "./EditUser.css";

const EditUser = () => {
  return (
    <Fragment>
      <div className="edit-user-container">
        <div className="edit-user-title">
          <h2>EDIT USER DETAILS</h2>
        </div>
        <div className="edit-details">
          <div className="edit-user-details-row">
            <div className="input-with-label">
            <label>First Name</label>
            <input type="text" placeholder="First Name"/>
            </div>
            <div className="input-with-label">
            <label>Last Name</label>
            <input type="text" placeholder="Last Name"/>
            </div>
          </div>
          <div className="edit-user-details-row">
            <div className="input-with-label">
            <label>Email</label>
            <input type="text" placeholder="Email"/>
            </div>
            <div className="input-with-label">
            <label>Phone</label>
            <input type="text" placeholder="Phone"/>
            </div></div>
        </div>
        <div className="roles">
            <h3>Roles</h3>
            <div className="roles-checkbox">
                <div className="roles-checkbox-first-column">
                    <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">NSU</label>
            </div>
            <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">Software</label>
            </div>
            <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">OTA Approver</label>
            </div>
            </div >           
            <div className="roles-checkbox-second-column">
                    <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">FEV Admin</label>
            </div>
            <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">FEV Service Tech</label>
            </div>
            <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">Release Certifier</label>
            </div>
            </div>
            <div className="roles-checkbox-third-column">
                    <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">FEV(Read Only)</label>
            </div>
            <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">OTA Manager</label>
            </div>
            </div>
            </div>
        </div>
        <div className="edit-user-last-column">
            <div className="last-checkboxes">
                <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">Fleet Admin</label>
            </div>
            <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">Fleet Service Tech</label>
            </div>
            <div className="roles-input-with-label">
            <input className="roles-checkbox-input" type="checkbox"/>
            <label className="roles-checkbox-label">Driver</label>
            </div>
            </div>
            <div className="notes">
                <h3>Notes:</h3>
                <h3>- FEV roles and Fleet roles "should" not be combined unless with extreme caution.</h3>
                <h3>- FEV Service Tech has access to ALL vehicles.</h3>
            </div>
            <div className="edit-user-buttons">
                <button className="add">CANCEL</button>
                <button className="add">UPDATE</button>
            </div>
        </div>
      </div>
    </Fragment>
  );
};

export default EditUser;
