import React, { Fragment, useState } from "react";
import "./AssignUnits.css";

const AssignUnits = () => {

    const [transferredDrivers, setTransferredDrivers] = useState<any[]>([]);

    const [drivers, setDrivers] = useState<any[]>([
      { name: "Unit 1", product: "Fev-tre",  selected: false },
      { name: "Unit 2", selected: false },
      { name: "Unit 3", selected: false },
      { name: "Unit 4", selected: false },
      { name: "Unit 5", selected: false },
      { name: "Unit 6", selected: false },
      // // Add more drivers as needed
    ]);
  
    const handleCheckboxChange = (index: number) => {
      const updatedDrivers = [...drivers];
      updatedDrivers[index] = {
        ...updatedDrivers[index],
        selected: !updatedDrivers[index].selected,
      };
      setDrivers(updatedDrivers);
    };
  
    const handleTransferredCheckboxChange = (index: number) => {
      const updatedTransferredDrivers = [...transferredDrivers];
      updatedTransferredDrivers[index] = {
        ...updatedTransferredDrivers[index],
        selected: !updatedTransferredDrivers[index].selected,
      };
      setTransferredDrivers(updatedTransferredDrivers);
    };
  
    const handleTransfer = () => {
      const selectedDrivers = drivers.filter((driver) => driver.selected);
      setTransferredDrivers([...transferredDrivers, ...selectedDrivers]);
      setDrivers(drivers.filter((driver) => !driver.selected));
    };
  
    const handleTransferToAvailable = () => {
      const selectedTransferredDrivers = transferredDrivers.filter(
        (driver) => driver.selected
      );
      setDrivers([...drivers, ...selectedTransferredDrivers]);
      setTransferredDrivers(
        transferredDrivers.filter((driver) => !driver.selected)
      );
    };
  
    const handleSelectAll = () => {
      const updatedDrivers = drivers.map((driver) => ({
        ...driver,
        selected: true,
      }));
      setDrivers(updatedDrivers);
    };
  
    const handleSelectAllTransferred = () => {
      const updatedTransferredDrivers = transferredDrivers.map((driver) => ({
        ...driver,
        selected: true,
      }));
      setTransferredDrivers(updatedTransferredDrivers);
    };
  
  
    const handleClearAll = () => {
      const updatedDrivers = drivers.map(driver => ({ ...driver, selected: false }));
      setDrivers(updatedDrivers);
    };
  
    const handleClearAllTransferred = () => {
      const updatedTransferredDrivers = transferredDrivers.map(driver => ({ ...driver, selected: false }));
      setTransferredDrivers(updatedTransferredDrivers);
    };


    return (
        <Fragment>
            <div className="driver-popup">
            <div className="assign-driver-title">
              <div>
                <h2>ASSIGN UNITS</h2>
              </div>
              <div>
                <span>
                  <h4>User: </h4>
                  <h4>Ankush Bhalage</h4>
                </span>
              </div>
            </div>
            <div className="assign-driver-second-row">
              <div className="search-assign-driver">
                <input type="text" placeholder="Search" />
                <span>
                  <i className="las la-search"></i>
                </span>
              </div>
              <div className="driver-selection">
                <div className="selected-assign-driver">
                  <div className="selected-assign-driver-first-row">
                    <h3>ASSIGNED UNITS</h3>
                    <h3>SELECTED</h3>
                  </div>
                  <div className="selected-assign-unit-second-row">
                    <h3>VIN</h3>
                    <span>
                      <button className="unit-select-all" onClick={handleSelectAll}>
                        <h3>Select All</h3>
                      </button>
                      <button className="unit-clear" onClick={handleClearAll}>
                        <h3>Clear</h3>
                      </button>
                    </span>
                  </div>
                  <div className="selected-assign-driver-third-row">
                    {drivers.map((driver, index) => (
                      <label key={index} className="checkbox-label">
                        <input
                          className="checkbox"
                          type="checkbox"
                          checked={driver.selected}
                          onChange={() => handleCheckboxChange(index)}
                        />
                        {driver.name}
                      </label>
                    ))}
                  </div>
                </div>
                <div className="arrow-buttons">
                  <button
                    className="arrow"
                    onClick={handleTransferToAvailable}
                  ></button>
                  <button className="arrow" onClick={handleTransfer}></button>
                </div>
                <div className="available-drivers">
                  <div className="available-drivers-first-row">
                    <h3>AVAILABLE UNITS</h3>
                    <h3>SELECTED</h3>
                  </div>
                  <div className="available-units-second-row">
                    <h3>VIN</h3>
                    <span>
                      <button
                        className="unit-select-all"
                        onClick={handleSelectAllTransferred}
                      >
                        <h3>Select All</h3>
                      </button>
                      <button className="unit-clear" onClick={handleClearAllTransferred}>
                        <h3>Clear</h3>
                      </button>
                    </span>
                  </div>
                  <div className="selected-assign-driver-third-row">
                    {transferredDrivers.map((driver, index) => (
                      <div key={index}>
                        <label className="checkbox-label">
                          <input
                            className="checkbox"
                            type="checkbox"
                            checked={driver.selected}
                            onChange={() =>
                              handleTransferredCheckboxChange(index)
                            }
                          />
                          {driver.name}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="assigned-driver-apply">
              <button className="add">CANCEL</button>
              <button className="add">ASSIGN UNITS</button>
            </div>
          </div>
        </Fragment>
    )

};

export default AssignUnits;