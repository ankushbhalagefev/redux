import React, { useState } from 'react'
import './Login.css'
import { Link} from 'react-router-dom'
import { useFormik } from 'formik'
import { loginSchema } from '../../Middleware/Schema'
import Fleet_command_logo from '../../assets/images/Feet_command_logo.png'

import Auth from '../../Middleware/Auth'
import axios from 'axios'
import Loader from '../../Middleware/Loader'
const Login = () => {
  const[loading,setLoading]=useState(false);
  const initialValues = {
    email: "",
    password: ""
  }

  const {setToken}=Auth();
 
  const {
    values,
    handleBlur,
    handleChange,
    handleSubmit,
    errors,
    touched,
    resetForm,
  } = useFormik({
    initialValues,
    validationSchema: loginSchema,
    validateOnChange: true,
    validateOnBlur: false,

    onSubmit: (values, action) => {
      console.log('Form values:', values);
      const data={
        email: values.email,
        password: values.password,
        orgId: "Fev",
        connectedApp: {
          app: "PKI",
          role: "Admin"
        }}
        setLoading(true);
      axios.post('http://localhost:8088/api/v1/um/signIn',data).then((resp)=>{
        console.log(resp.data)
        setToken(resp.data.extras.idToken);
        setLoading(false);
      }).catch((err)=>{
         console.log(err)
            
      })
      action.resetForm();
    }
  }
  )

  return (
    <div>
      <div className='login_container'>
        <div className='login_form'>
          <div className='login_logo'><img src={Fleet_command_logo} alt='fleet_command logo' /></div>
          <form onSubmit={handleSubmit}>
            <h2>Login</h2>
            <div>
              <label htmlFor="email">Email Id</label>
              <input type='text' id='email' value={values.email} onBlur={handleBlur} onChange={handleChange} placeholder='Enter email id' />
              {
                touched.email && errors.email ? (
                  <p style={{ color: 'red' }}>{errors.email}</p>
                ) : null
              }
            </div>
            <div>
              <label htmlFor="password">Password</label>
              <input type='password' id='password' value={values.password} onBlur={handleBlur} onChange={handleChange} placeholder='Enter your password' />
              {
                touched.password && errors.password ? (
                  <p style={{ color: 'red' }}>{errors.password}</p>
                ) : null
              }
            </div>
            <button className='login_button' type='submit'>{loading?<Loader/>:<>Login</>}</button>
            <div>
              <span>
                <Link to="/forgot_password">Forgot Password?</Link>
                <Link to="/resend_invitation">Did not receive invitation email?</Link>
              </span>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Login;