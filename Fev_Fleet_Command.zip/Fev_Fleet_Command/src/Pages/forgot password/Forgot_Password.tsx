import React from 'react'
import './Forgot_Password.css'
import Fleet_command_logo from '../../assets/images/Feet_command_logo.png'
const Forgot_Password = () => {
    return (
        <div className='login_container'>
            <div className='login_form'>
            <div className='login_logo'><img src={Fleet_command_logo} alt='fleet_command logo'/></div>

                <form>
                    <h4 className='fp_heading'>Please set a new password.</h4>
                    <div className='password_policy'>
                        <p>Password must contain the following:</p>

                        <p>1.Minimum 8 characters long </p>
                        <p>2.Have at least 1 digit</p>
                        <p>3.Have at least 1 special character</p>
                        <p>4.Have at least 1 upeercase</p>
                    </div>
                    <div>
                        <label>Email</label>
                        <input />
                    </div>
                    <div>
                        <label>New Password</label>
                        <input />
                    </div>
                    <div>
                        <label>Confirm Password</label>
                        <input />
                    </div>
                    <button className=' forogt_password add'>Submit</button>
                </form>
            </div>
        </div>
    )
}

export default Forgot_Password