import React, { useEffect, useState } from 'react'
import './Pki.css'
import { useFormik } from 'formik';
import axios from 'axios';
import DataTable, { TableColumn } from 'react-data-table-component';
const Pki = () => {
    const [hasKeypair, setHasKeypair] = useState(true);
    const [fileName, setFileName] = useState("");
    const [alg, setSelectAlgo] = useState("");
    const [size, setKeySize] = useState("");
    const [sizeArray, setSizeArray] = useState<number[]>([]);
    const handleFileInput = () => {
        const fileInput = document.querySelector('.file-input')! as HTMLInputElement;;

        fileInput.click();
    }
    const initialValues = {
        userId: "",
        orgId: "",
        commonName: "",
        ecuName: "",
        ecuVarientId: "",
        email: ""
    }

    const {
        values,
        handleBlur,
        handleChange,
        handleSubmit,
        errors,
        touched,
        resetForm,
    } = useFormik({
        initialValues,
        // validationSchema: loginSchema,
        validateOnChange: true,
        validateOnBlur: false,

        onSubmit: (values, action) => {
            console.log('Form values:', values);
            const formData=new FormData();
            formData.append('CSRDto',JSON.stringify({
                commonName:values.commonName,
                alg,
                size,
                ecuName:values.ecuName,
                ecuVarientId:values.ecuVarientId
            }));
            generateCrtificate()
            action.resetForm();
        }
    }
    )
    const customStyles = {

        headCells: {
            style: {
                paddingLeft: '8px', // override the cell padding for head cells
                paddingRight: '8px',
                backgroundColor: '#edf4fb',
                color: '#24356c',
                fontSize: '13px',
                fontWeight: '500',
                width:'10rem'
            },
        },
        cells: {
          style: {
            color: 'gray',
            fontWeight: '700'
          }
        },
      };
      
    const generateCrtificate=async()=>{
        const formData=new FormData();
            formData.append('CSRDto',JSON.stringify({
                commonName:values.commonName,
                alg,
                size,
                ecuName:values.ecuName,
                ecuVarientId:values.ecuVarientId
            }));
        try {
            const token = sessionStorage.getItem('token');
            console.log(token);
            if (!token) {
              console.error('Token not found in sessionStorage.');
              return;
            }
            const cleanedToken = token.replace(/"/g, '');
            console.log("cleanedToken", cleanedToken);
            console.log("formData", formData);
      
            const response = await axios.post(
              "http://localhost:9091/api/v1/csr/generateCSR",
              formData,
              {
                headers: {
                  'Authorization': `Bearer ${cleanedToken}`,
                  //      "Content-Type": "multipart/form-data"
                },
              }
            );
            console.log("genecsrresp", response.data)
        } catch (error) {
            
        }
    }
    const changeSize = (val: string) => {
        switch (val) {
            case "RSA":
                setSizeArray([1024, 2048, 3072, 4096]);
                break;
            case "DSA":
                setSizeArray([1024, 2048, 3072]);
                break;
            case "ECDSA":
                setSizeArray([521, 384, 256]);
                break;

        }
    }
    interface UserData {
        requestId: number;
        userId: string;
        orgId: string,
        commonName: string,
        email: string;
        CSRGenTime: string;
        status: string;
        ecuName:string;
        ecuVarientId:string;
      
      }
      const columns: TableColumn<UserData>[] = [
        {
          name: 'Organization ID',
          selector: (row) => row.orgId,
          sortable: true,
        },
        {
          name: 'Common Name',
          selector: (row) => row.commonName,
          sortable: true,
        },
        {
          name: 'Email',
          selector: (row) => row.email,
          sortable: true,
        },
        {
          name: 'ECU Name',
          selector: (row) => row.ecuName,
          sortable: true,
        },
        {
          name: 'ECU Varient ID',
          selector: (row) => row.ecuVarientId,
          sortable: true,
        },
        {
          name: 'Status',
          sortable: true,
          cell: row => {
            return (
              <span className='cell-status'> Success </span>
            );
          }
        },
      ];
      const [data, setData] = useState<UserData[]>([]);
      const fetchData = async () => {
        try {
          const token = sessionStorage.getItem('token');
          console.log(token);
          if (!token) {
            console.error('Token not found in sessionStorage.');
            return;
          }
          const cleanedToken = token.replace(/"/g, '');
          const getUserId = await axios.get(`http://localhost:8088/api/v1/um/decode/${token}`);
    
        console.log(" update cert userid", getUserId.data.extras);
    
          const response = await axios.get(`http://localhost:9091/api/v1/csr/getemail/${getUserId.data.extras.email}`, 
          {
            headers: {
              'Authorization': `Bearer ${cleanedToken}`
              // "Content-Type": "multipart/form-data"
            },
           
          });
          console.log("user",response)
          // const jsonData: UserData[] = await response.json();
          setData(response.data);
        } catch (error) {
          console.error('Error:', error);
        }
      };
      useEffect(() => {
        fetchData();
      }, []);
      useEffect(()=>{

      },[])
    return <>
        <div className='pkiContainer'>

            <form className='popup-form csrForm' onSubmit={handleSubmit}>
                <h3>Generate Certificate</h3>
                {/* <div className='common_input'>
                    <label>UserId</label>
                    <input type='text' name='userId' value={values.userId} onChange={handleChange} />
                </div> */}
                {/* <div className='common_input'>
                    <label>Organizarion ID</label>
                    <input type='text' name='orgId' value={values.orgId} onChange={handleChange} />
                </div> */}
                <div className='common_input'>
                    <label>Common Name</label>
                    <input type='text' name='commonName' value={values.commonName} onChange={handleChange} />
                </div>
                <div className='common_input'>
                    <label>ECU Name</label>
                    <input type='text' name='ecuName' value={values.ecuName} onChange={handleChange} />
                </div>
                <div className='common_input'>
                    <label>ECU variant Id</label>
                    <input type='text' name='ecuVarientId' value={values.ecuVarientId} onChange={handleChange} />
                </div>
                <div className='common_input'>
                    <label>Email ID</label>
                    <input type='text' name='email' value={values.email} onChange={handleChange} />
                </div>
                <div className='hasKeyPair'>

                    <input type='checkbox' checked={hasKeypair} onChange={() => setHasKeypair(!hasKeypair)} />
                    <label>I have key pair</label>
                </div>
                {
                    hasKeypair ? <>
                        <div onClick={handleFileInput} className="custom-file-input">

                            <input
                                type="file"
                                className="file-input"
                                hidden
                                onChange={({ target: { files } }) => {
                                    files && files[0] && setFileName(files[0].name)
                                }}
                            />
                            {/* only dipslay 10 characters of the selected file name */}
                            {fileName ? <span>{fileName.substring(0, 10)} {fileName.length > 10 ? '...' : ''}</span>
                                :
                                <>
                                    <i className="las la-cloud-upload-alt"></i>
                                    <span className="uploadButton">Upload Key Pair </span>
                                </>
                            }
                        </div>
                    </> : <> <div className='common_input'>
                        <label>Select Crypto</label>
                        <select value={alg} onChange={e => { setSelectAlgo(e.target.value); changeSize(e.target.value) }}>
                            <option value="none">Select Crypto</option>
                            <option value="RSA">RSA</option>
                            <option value="DSA">DSA</option>
                            <option value="ECDSA">ECDSA</option>
                        </select>
                    </div>
                        <div className='common_input'>
                            <label>Select Key Size</label>
                            <select value={size} name="Select Key size" onChange={e => setKeySize(e.target.value)}>
                                <option value="0">Select Key size</option>
                                {sizeArray.map((number, index) => (
                                    <option key={number} value={number}>{number}</option>
                                ))}
                            </select>
                        </div>
                    </>
                }
                <div>
                    <button>cancel</button>
                    <button type='submit'>Submit</button>
                </div>
            </form>
            <div>

            </div>
            <div>

            </div>
            <div className='pki-table'>
                <DataTable
                columns={columns}
                data={data}
                title="CSR LIST"
                customStyles={customStyles}
                />
            </div>

        </div>
    </>
}

export default Pki