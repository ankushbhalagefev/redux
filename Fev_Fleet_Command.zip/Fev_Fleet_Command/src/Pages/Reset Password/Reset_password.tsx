import { useFormik } from 'formik'
import React from 'react'
import { resetPasswordSchema } from '../../Middleware/Schema'
import Fleet_command_logo from '../../assets/images/Feet_command_logo.png'
const Reset_password = () => {
  const initialValues={
    password:"",
    confirm_password:""

  }

  const {
    values,
    handleBlur,
    handleChange,
    handleSubmit,
    errors,
    touched,
    resetForm,
  } = useFormik({
    initialValues,
    validationSchema: resetPasswordSchema,
    validateOnChange: true,
    validateOnBlur: false,
   
    onSubmit: (values, action) => {
      console.log('Form values:', values);
      action.resetForm();}
    }
  )
  return (
    <div className='login_container'>
        <div className='login_form'>
        <div className='login_logo'><img src={Fleet_command_logo} alt='fleet_command logo'/></div>

            <form onSubmit={handleSubmit}>
                <h4 className='fp_heading'>Please set password to create your account.</h4>
                <div className='password_policy'>
                    <p>Password must contain the following:</p>
                    <p>1.Minimum 8 characters long </p>
                    <p>2.Have at least 1 digit</p>
                    <p>3.Have at least 1 special character</p>
                    <p>4.Have at least 1 upeercase</p>
                </div>
               
                <div>
                    <label>New Password</label>
                    <input type='password' id='password' value={values.password} onBlur={handleBlur} onChange={handleChange}/>
                    {
              touched.password && errors.password ? (
                <p style={{ color: 'red' }}>{errors.password}</p>
              ) : null
            }
                </div>
                <div>
                    <label>Confirm Password</label>
                    <input type='password' id='confirm_password' value={values.confirm_password} onBlur={handleBlur} onChange={handleChange}/>
                    {
              touched.confirm_password && errors.confirm_password ? (
                <p style={{ color: 'red' }}>{errors.confirm_password}</p>
              ) : null
            }
                </div>
                <button className=' forogt_password add' type='submit'>Create my account</button>
            </form>
        </div>
    </div>
)
}

export default Reset_password;