import React, { useEffect, useState } from 'react'
import DataTable, { TableColumn } from 'react-data-table-component'
import Popup from '../../Components/Popup/Popup'
import { useNavigate } from 'react-router-dom'
import { RootState, useAppDispatch } from '../../redux/store'
import { createUser, getAllUsers } from '../../redux/User/UsersApi'
import { useSelector } from "react-redux"
import { searchUser } from '../../redux/User/UserSlice'
import { useFormik } from 'formik'
import { addUserSchema } from '../../Middleware/Schema'
import Loader from '../../Middleware/Loader'
const Users = () => {
  interface DataRow {
    id:number,
    first_name: string,
    last_name: string,
    email: string,
    phone: string,
    roles:string[]

  }
  const initialValues = {
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    roles:[""]
  };
  const [search, setSearch] = useState("");
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { users,userLoading } = useSelector((state: RootState) => state.UsersSlice);

  const {
    values,
    handleBlur,
    handleChange,
    handleSubmit,
    errors,
    touched,
    resetForm,
  } = useFormik({
    initialValues,
    validationSchema: addUserSchema,
    validateOnChange: true,
    validateOnBlur: false,
   
    onSubmit: (values, action) => {
      // Create an array to store the selected roles
      const selectedRoles = [];
    
      // Check each checkbox and add the role to the selectedRoles array if it's selected
      const superUserCheckbox = document.getElementById('superUser') as HTMLInputElement;
      if (superUserCheckbox?.checked) {
        selectedRoles.push('SuperUser');
      }
    
      const adminCheckbox = document.getElementById('admin') as HTMLInputElement;
      if (adminCheckbox?.checked) {
        selectedRoles.push('Admin');
      }
    
      const driverCheckbox = document.getElementById('driver') as HTMLInputElement;
      if (driverCheckbox?.checked) {
        selectedRoles.push('Driver');
      }
    
      const otaApproverCheckbox = document.getElementById('ota_approver') as HTMLInputElement;
      if (otaApproverCheckbox?.checked) {
        selectedRoles.push('OTA Approver');
      }
    
      const releaseCertifierCheckbox = document.getElementById('release_certifier') as HTMLInputElement;
      if (releaseCertifierCheckbox?.checked) {
        selectedRoles.push('Release Certifier');
      }
    
      // Update the roles property in the values object
      values.roles = selectedRoles;
    
      // You can now do something with the updated values, such as submitting them to a server
      console.log('Form values:', values);
      dispatch(createUser(
        {
            id: users.length + 1,
            first_name: values.first_name,
            email: values.email,
            last_name:values.last_name,
            phone:values.phone,
            roles: values.roles
        }));
      // Reset the form after submission
      action.resetForm();
    },
    
  });
  console.log(errors);
  const column: TableColumn<DataRow>[] = [
    {
      name: 'Name',
      selector: row => row.first_name + " "+ row.last_name,
    },
    {
      name: 'Email',
      selector: row => row.email,
    },
    {
      name: 'Role',
      selector: (row) => (row.roles ? row.roles.join(', ') : ''),
    }
  ]
  useEffect(() => {

    dispatch(getAllUsers())
  }, [dispatch]);

  
  useEffect(() => {
    dispatch(searchUser({ search }))
  }, [search])
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const openPopup = () => {

    setIsPopupOpen(true);
  };

  const closePopup = () => {
    setIsPopupOpen(false);
  };
  return (<> 
    <div className='globalContainer'>
      <h3>Users</h3>
      <div className='search-bar'>
        <span className='search'><input type='search' placeholder='Search for user' value={search} onChange={e => setSearch(e.target.value)} /> <i className='lab la-searchengin'></i></span>
        <button className='add' onClick={() => openPopup()}><i className='las la-plus'></i> User</button>
      </div>
      <div className='table-container'>
{
userLoading?<Loader/>:
        <DataTable

          className='datatable_component'
          columns={column}
          data={users}
          pointerOnHover
          responsive={true}
          pagination
          fixedHeader
          onRowClicked={(row: DataRow) => navigate(`${row.id}`)}
          striped
          

        />}

      </div>
      <Popup key="User" isOpen={isPopupOpen} onClose={closePopup}>

        <form className='popup-form' onSubmit={handleSubmit}>
          <h3>Add new User</h3>
          <div className='common_input'>
            <label>first name*</label>
            <input type='text' id='first_name' value={values.first_name} onBlur={handleBlur} onChange={handleChange} />
            {
              touched
                .first_name && errors.first_name ? (
                <p style={{ color: 'red' }}>{errors.first_name}</p>
              ) : null
            }
          </div>
          <div className='common_input'>
            <label>last name*</label>
            <input type="text" id='last_name' value={values.last_name} onBlur={handleBlur} onChange={handleChange} />
            {
              touched.last_name && errors.last_name ? (
                <p style={{ color: 'red' }}>{errors.last_name}</p>
              ) : null
            }
          </div >
          <div className='common_input'>
            <label>email*</label>
            <input type='email' id='email' value={values.email} onBlur={handleBlur} onChange={handleChange} />
            {
              touched.email && errors.email ? (
                <p style={{ color: 'red' }}>{errors.email}</p>
              ) : null
            }
          </div>
          <div className='common_input'>
            <label>phone</label>
            <input type='text' id='phone' value={values.phone} onBlur={handleBlur} onChange={handleChange} />
          </div>
          <div className='ghjkk'>
            <label>Assign Role*</label>
            <div className='assign_role'>
              <div><div><input type='checkbox' id='superUser'/> <label htmlFor='superUser'>SuperUser</label></div>
                <div><input type='checkbox' id='admin' /><label htmlFor='admin'>Admin</label></div>
                <div><input type='checkbox' id='driver' /><label htmlFor='admin'>Driver</label></div></div>
              <div> <div><input type='checkbox' id='ota_approver' /><label htmlFor='ota_approver'>OTA Approver</label></div>
                <div><input type='checkbox' id='release_certifier' /><label htmlFor='release_certifier'>Release Certifier</label></div></div>
            </div>
          </div>
          <div>
            <button >Cancel</button>
            <button type='submit'>ADD USER</button>
          </div>
        </form>
      </Popup>
    </div>
    </>
  )
}

export default Users;