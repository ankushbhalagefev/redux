import React, { useState, Fragment } from "react";
import Header from '../../Components/Header/Header';
import Sidebar from '../../Components/Sidebar/Sidebar';

import "./Ota.css";
import Timeline from "../../Components/Timeline/Timeline";



const Ota = () => {
 
    return (
        <Fragment>
            <Header/>
            <Sidebar/>
            <div className="ota-container">
                <div className="timeline-container">
                    <h1 className="ota-title">CREATE RELEASE</h1>
            <Timeline/>

            <div className="select-options">
                <div className="select-option-div">
                    <h5>Choose Product*:</h5>
                <select className="choose-product">
                    <option className="option" value="">Select a Product</option>
                    <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option>
                </select>
                </div>
                <div className="select-option-div">
                    <h5>Release Name:</h5>
                <input type="text" className="ota-input" placeholder="Release Name"/>
                    
                </div>
                <div className="select-option-div">
                    <h5>Release Version:</h5>
                <input type="text" className="ota-input" placeholder="Version Name"/>
                </div>
                </div>
                <div className="release-name">
                <h5>Release Note:</h5>
                    <textarea className="release-name-input" placeholder="Add a release note here"/>
                </div>
                <div className="ota-product-buttons">
                    <button className="add">CANCEL</button>
                    <button className="add">SAVE DRAFT</button>
                    <button className="add">ADD ECU</button>


                </div>
            </div>
           </div>
           
          
        </Fragment>
    )
};

export default Ota;