import React, { useState } from 'react'
import Popup from '../../Components/Popup/Popup'
import System from '../System/System';
import Ecu from '../ECU/Ecu';

const Model = () => {
    const [isPopupOpen, setIsPopupOpen] = useState(false);
    const [search, setSearch] = useState("");
    const openPopup = () => {

        setIsPopupOpen(true);
    };

    const closePopup = () => {
        setIsPopupOpen(false);
    };

  return (
    <>
    <div className='globalContainer'>
    <h3>Model</h3>
            <div className='search-bar'>
                <span className='search'><input type='search' placeholder='Search for model' value={search} onChange={e => setSearch(e.target.value)} /> <i className='lab la-searchengin'></i></span>
                <button className='add' onClick={() => openPopup()}><i className='las la-plus'></i> Model</button>
            </div>
            <div className="table-container">
                {/* <DataTable
                className='datatable_component'
                columns={column}
                pointerOnHover
                responsive={true}
                pagination
                fixedHeader
                striped
                /> */}
            </div>
            <Popup key="model" isOpen={isPopupOpen} onClose={closePopup}>
              <form className='popup-form'>
                 <h3>Add Model</h3>
                 <div className='common_input'>
                    <label>Variant name *</label>
                 <input />
                 </div>
                 <div className='common_input'>
                    <label>Select Product *</label>
                    <select></select>
                 </div>
                 <div>
                    <button onClick={closePopup}>Cancel</button>
                    <button>Add Variant</button>
                 </div>
              </form>
            </Popup>
        </div>
       
      <System/>
      <Ecu/>
    </>
  )
}

export default Model