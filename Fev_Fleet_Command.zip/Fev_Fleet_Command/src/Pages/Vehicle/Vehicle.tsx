import React, { useEffect, useState } from 'react'
import DataTable, { TableColumn } from 'react-data-table-component'
import { RootState, useAppDispatch } from '../../redux/store'
import { getAllVehicles } from '../../redux/Vehicle/VehicleApi'
import { useSelector } from 'react-redux'
import { searchVehicle } from '../../redux/Vehicle/VehicleSlice'
import Popup from '../../Components/Popup/Popup'
import { useNavigate } from 'react-router-dom'
const Vehicle = () => {
    const navigate=useNavigate();
    interface DataRow {
        id: number,
        vin: string,
        vehicleName: string,
        fleetName: string,
        currentDriver: string


    }
    const column: TableColumn<DataRow>[] = [
        {
            name: 'VIN',
            selector: row => row.vin,
        },
        {
            name: 'Vehicle Name',
            selector: row => row.vehicleName,
        },
        {
            name: 'Fleet Name',
            selector: row => row.fleetName,
        },
        {
            name: 'Current Driver',
            selector: row => row.currentDriver,
        },

    ]
    const dispatch = useAppDispatch();
    const { vehicles } = useSelector((state: RootState) => state.vehicleSlice);
    const {fleets}=useSelector((state:RootState)=>state.fleetSlice);
    const [isPopupOpen, setIsPopupOpen] = useState(false);
    const [search, setSearch] = useState("");

    const openPopup = () => {

        setIsPopupOpen(true);
    };

    const closePopup = () => {
        setIsPopupOpen(false);
    };
    useEffect(() => {
        dispatch(getAllVehicles())
    }, [dispatch]);
    useEffect(() => {
        dispatch(searchVehicle({ search }))
    }, [search])
    return (
        <>
           
            <div className='globalContainer'>
                <h3>Vehicles</h3>
                <div className='search-bar'>
                    <span><input type='search' placeholder='Search for Vehicle' onChange={e => setSearch(e.target.value)} /> <i className='lab la-searchengin'></i></span>
                    <button className='add' onClick={() => openPopup()}><i className='las la-plus'></i> Vehicle</button>
                </div>
                <div className='table-container'>

                    <DataTable

                        className='datatable_component'
                        columns={column}
                        data={vehicles}
                        pointerOnHover
                        responsive={true}
                        pagination
                        fixedHeader
                          onRowClicked={(row: DataRow) => navigate(`${row.id}`)}
                        striped

                    />

                </div>
                <Popup key="vehicle" isOpen={isPopupOpen} onClose={closePopup}>
<form className='popup-form'>
          <h3>Add Vehicle</h3>
          <div className='common_input'>
            <label>VIN*</label>
            <input type='text' id='first_name'  />
            
          </div>
          <div className='common_input'>
            <label>Vehicle Name*</label>
            <input type="text" id='last_name' />
            
          </div >
          <div className='common_input'>
            <label>Product Family*</label>
            {/* <input type='email' id='email'  /> */}
            <select>
            <option selected value="0">Select </option>
            <option>Last hour</option>
            <option>Last day </option>
            </select>
            
          </div>
          <div className='common_input'>
            <label>Fleet*</label>
            {/* <input type='email' id='email'  /> */}
            <select>
            <option selected value="0" >Select </option>
            <option>Fleet 1</option>
            <option>Fleet 2</option>
            </select>
            
          </div>
          <div className='ghkkkkkkkkkkj'>
          <div>
            <button >Cancel</button>
            <button type='submit'>ADD Vehicle</button>
          </div>
          </div>
        </form>
                </Popup>
            </div>
        </>
    )
}

export default Vehicle