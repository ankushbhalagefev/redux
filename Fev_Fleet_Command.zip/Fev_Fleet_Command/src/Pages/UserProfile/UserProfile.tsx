import React from 'react'
import './UserProfile.css'
const UserProfile = () => {
   
    return (
        <>
            <div className='globalContainer'>
                <h3>USER PROFILE</h3>
                <div>
                    <form>
                        <div className='profile_update' >
                            <div className='profile_input'>
                                <label>First Name</label>
                                <input type='text' placeholder='First Name'/>
                            </div>
                            <div className='profile_input'><label>Last Name</label>
                                <input type='text' placeholder='Last Name'/>
                            </div>
                            <div className='profile_input'><label>Email</label>
                                <input type='text'placeholder='Email'/>
                            </div>
                            <div className='profile_input'><label>Phone</label>
                                <input type='text'  placeholder='Phone Number'/>
                            </div>
                        </div>
                        <div className='profile_update'>
                            <div className='profile_input'>
                                <label>Roles</label>
                                <input />
                            </div>
                            <div className='profile_input'>
                                <label>Assigned Fleets</label>
                                <input/>
                            </div>
                            <div className='profile_input'>
                                <label>Date Created</label>
                                <input/>
                            </div>
                        </div>
                        <div className='profle_submit'>
                            <div><button className='cancel'>Cancel</button></div>
                            <div><button className='update_button'>Update Profile</button></div>

                        </div>
                    </form>
                </div>

            </div>
            <div className='lower_container_updateProfile'>
                <div className='units_profile'>
                    <h3>Assigned Units</h3>
                </div>
                <div className='password_profile'>
                    <h2>Password</h2>
                    <p>Password must contain the following:</p>

                    <p>1.Minimum 8 characters long </p>
                    <p>2.Have at least 1 digit</p>
                    <p>3.Have at least 1 special character</p>
                    <p>4.Have at least 1 upeercase</p>
                    <form className='password_input'>
                    <div>
                        <div className='profile_input'>
                            <label>New Password</label>
                            <input type='password' placeholder='New Password'/>
                        </div>
                        <div className='profile_input'>
                            <label>Confirm Password</label>
                            <input type='password' placeholder='Confirm Password'/>
                        </div>
                        </div>
                        <div className='profle_submit'>
                            <div><button className='cancel'>Cancel</button></div>
                            <div><button className='update_button'>Update Password</button></div>

                        </div>
                    </form>
                </div>
            </div>
        </>
    )
}

export default UserProfile