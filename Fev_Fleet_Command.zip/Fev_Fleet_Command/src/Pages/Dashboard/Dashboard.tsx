import React from 'react'
import './Dashboard.css'
import Barchart from '../../Components/Barchart/Barchart'
import Map from '../../Components/Map/Map';
const Dashboard = () => {
  return (<>
 
    <div className='dashboard_container'>
      <div className='map_chart'>
      <div className='card'> <Map width="730px" height="295px"  markers={[
    { latitude: 18.5204, longitude: 73.8567 },
    
    // Add more markers as needed
    // Add more markers as needed
  ]} /></div>
        <div className='card'> <Barchart /></div>
      </div>
      <div className='driving_analysis'>
        
          <h4>driving analysis</h4>
        
        <div className='driving_analysis_tab'>
          <div className='driving_card'><span><h5>Vehicle reporting</h5> <h1>121</h1> <h5>of 1335</h5></span></div>
          <div className='driving_card'><span><h5>fatigue events</h5> <h1>5</h1> <h5>347km  7Hours</h5></span></div>
          <div className='driving_card'><span><h5>tracking</h5> <h1>44%</h1> <h5>performance</h5></span></div>
          <div className='driving_card'><span><h5>distance travelled</h5> <h1>1334</h1> <h5>km</h5></span></div>
          <div className='driving_card'><span><h5>fatigue risk</h5> <h1>17 &nbsp; &nbsp; &nbsp;6</h1> <h5>elevated &nbsp; critical</h5></span></div>
          <div className='driving_card'><span><h5>time period</h5> <select>
            <option>Select </option>
            <option>Last hour</option>
            <option>Last day </option>
            </select></span></div>

        </div>
        
      </div>
      <div className='driving_analysis'>
        
        <h4>vehicle analysis</h4>
      
      <div className='driving_analysis_tab'>
        <div className='driving_card'><span><h5>alert</h5> <h1>121</h1> </span></div>
        <div className='driving_card'><span><h5>thermal failure</h5> <h1>121</h1> </span></div>
        <div className='driving_card'><span><h5>predicted failure</h5> <h1>121</h1> </span></div>
        <div className='driving_card'><span><h5>Vehicles</h5> <h1>121</h1> </span></div>
        <div className='driving_card'><span><h5>extras</h5> <h1>121</h1> </span></div>
        <div className='driving_card'><span><h5>extras</h5> <h1>121</h1> </span></div>

      </div>
      
    </div>
    </div>
    </>
  )
}

export default Dashboard