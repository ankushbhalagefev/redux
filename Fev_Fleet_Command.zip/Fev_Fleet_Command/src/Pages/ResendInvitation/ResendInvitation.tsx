import React from 'react'
import './ResendInvitation.css'
import { useNavigate } from 'react-router-dom'
import Fleet_command_logo from '../../assets/images/Feet_command_logo.png'
const ResendInvitation = () => {
    const navigate =useNavigate();
    return (
        <div className='login_container'>
            <div className='login_form'>
                <div className='login_logo'>
                    <img src={Fleet_command_logo} alt='fleet_command logo' />
                </div>
                <form>
                    <div>
                        <label>Email</label>
                        <input />
                    </div>
                   <div> <button type='submit'className='send_email'>Send email</button></div>
                    <div><button type='button'  onClick={()=>navigate("/login")}className='return_to_sign_in'>return to sign in</button></div>
                </form>
            </div>
        </div>
    )
}

export default ResendInvitation