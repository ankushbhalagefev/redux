import { UserDetail } from "./UserSlice";
import {createAsyncThunk} from "@reduxjs/toolkit"
import axios from "axios"
export const getAllUsers=createAsyncThunk<UserDetail[],void>(
    "getAllUsers",
    async(_,{rejectWithValue})=>{
        try {
            const response=await axios.get("http://localhost:3000/users")
            return response.data;
        } catch (error) {
            return rejectWithValue(error);
        }
    }
)
export const createUser = createAsyncThunk<UserDetail, UserDetail>(
    "addUser",
    async (data, { rejectWithValue }) => {
      try {

        const response=await axios.post("http://localhost:3000/users",data)
        console.log(response.data);
        return response.data;
      } catch (error) {
        return rejectWithValue(error);
      }
    }
  );
  export const getUserById=createAsyncThunk<{id:number},number>(
    "getUserById",
    async(id,{rejectWithValue})=>{
      try {
        const response=await axios.get(`http://localhost:3000/users/${id}`)
        console.log(response.data)
        return response.data;
      } catch (error) {
        return rejectWithValue(error);
      }
    }
  )