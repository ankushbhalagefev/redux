import {createSlice,PayloadAction} from "@reduxjs/toolkit"
import { createUser, getAllUsers, getUserById } from "./UsersApi";
import UserDetails from "../../Pages/UserDetails/UserDetail";

export interface UserDetail{
    id:number,
    first_name: string,
    last_name: string,
    email: string,
    phone: string,
    roles:string[]
}
interface UserDetailState {
  user:UserDetail;
    users: UserDetail[];
    userLoading: boolean;
    status:string;
    searchData:UserDetail[];
    id:number
  }
  const initialUserDetail: UserDetail = {
    id: 0,
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    roles: [],
  };
const initialState: UserDetailState = {
  user: initialUserDetail,
  users: [],
  userLoading: false,
  status: "",
  searchData:[],
  id:0
  
};
export const UsersSlice=createSlice({
    name:"users",
    initialState,
    reducers:{
        searchUser:(state,action:PayloadAction<{search:string}>)=>{
            const { search } = action.payload;
             if (search.trim() === "") {
               state.users = state.searchData;
             } else {
               const result = state.searchData.filter((item) =>
                 item.first_name.toLowerCase().includes(search.toLowerCase())
               );
               state.users = result;
             }
               } 
    },
    extraReducers:(builder)=>{
        builder.addCase(getAllUsers.pending,(state)=>{
           state.userLoading=true
        })
        .addCase(getAllUsers.fulfilled,(state,action)=>{
            state.userLoading=false
            state.users=action.payload
            state.searchData=action.payload;
        })
        .addCase(getAllUsers.rejected,(state)=>{
          state.userLoading=false
        })
        .addCase(createUser.pending,(state)=>{
          state.userLoading=true
        })
        .addCase(createUser.fulfilled,(state,action)=>{
          state.userLoading=false;
          state.users.push(action.payload);
        })
        .addCase(createUser.rejected, (state, action) => {
          state.userLoading = false;
          
        })
        .addCase(getUserById.pending,(state)=>{
          state.userLoading=true;
        })
        .addCase(getUserById.fulfilled,(state,action)=>{
          state.userLoading=false;
          state.user = { ...state.user, ...action.payload };
        })
        .addCase(getUserById.rejected,(state)=>{
          state.userLoading=false;
        })
    }
})
export const {reducer:UsersReducer}=UsersSlice;
export const{searchUser} = UsersSlice.actions;