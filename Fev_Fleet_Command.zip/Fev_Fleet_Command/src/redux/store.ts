import { configureStore } from '@reduxjs/toolkit';
import { useDispatch } from 'react-redux';
import { UsersReducer } from './User/UserSlice';
import { VehicleReducer } from './Vehicle/VehicleSlice';
import { fleetreducer } from './Fleet/FleetSlice';

export const store = configureStore({
  reducer:{
    UsersSlice:UsersReducer,
    vehicleSlice:VehicleReducer,
    fleetSlice:fleetreducer
  }
});


export type AppDispatch = typeof store.dispatch;
export const useAppDispatch = () => useDispatch<AppDispatch>();
export type RootState = ReturnType<typeof store.getState>;
