import { createSlice } from "@reduxjs/toolkit";
import { getAllFleets } from "./FleetApi";

export interface fleetDetails{
id:number,
name:string,
users:number,
vehicles:number
}
interface fleetState{
    fleet:fleetDetails;
    fleets:fleetDetails[],
    fleetLoading:boolean,
    searchData:fleetDetails[]
}
const initialFleetState:fleetDetails={
    id:0,
    name:"",
    users:0,
    vehicles:0

}
const initialState:fleetState={
fleet:initialFleetState,
fleets:[],
fleetLoading:false,
searchData:[]
}

export const fleetSlice=createSlice({
    name:"fleet",
    initialState,
    reducers:{},
    extraReducers:(builder)=>{
        builder
        .addCase(getAllFleets.pending,(state)=>{
            state.fleetLoading=true
        })
        .addCase(getAllFleets.fulfilled,(state,action)=>{
            state.fleetLoading=false;
            state.fleets=action.payload;
            state.searchData=action.payload;
        })
        .addCase(getAllFleets.rejected,(state)=>{
            state.fleetLoading=false
        })
    }
})

export const{reducer:fleetreducer}=fleetSlice;