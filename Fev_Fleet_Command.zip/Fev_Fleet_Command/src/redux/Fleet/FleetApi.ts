import { createAsyncThunk } from "@reduxjs/toolkit";
import { fleetDetails } from "./FleetSlice";
import axios from "axios";

export const getAllFleets=createAsyncThunk<fleetDetails[],void>(
    "getAllUsers",
    async(_,{rejectWithValue})=>{
        try {
            const response=await axios.get("http://localhost:3000/fleets")
            return response.data;
        } catch (error) {
            return rejectWithValue(error);
        }
    }
)
export const addFleet=createAsyncThunk<fleetDetails,fleetDetails>(
    "addFleet",
    async(data,{rejectWithValue})=>{
        try {
            const response=await axios.post("http://localhost:3000/fleets",data)
            return response.data;
        } catch (error) {
            return rejectWithValue(error);
        }
    }
)