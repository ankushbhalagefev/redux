import { PayloadAction, createSlice } from "@reduxjs/toolkit"
import { getAllVehicles } from "./VehicleApi"
import { string } from "yup"

export interface vehicleDetails {
    id: number,
    vin: string,
    vehicleName: string,
    fleetName: string,
    currentDriver: string
}
interface vehicleState {
    vehicles: vehicleDetails[],
    vehicleLoading: boolean,
    searchData: vehicleDetails[]
}
const initialState: vehicleState = {
    vehicles: [],
    vehicleLoading: false,
    searchData: []
}
export const vehicleSlice = createSlice({
    name: "vehicle",
    initialState,
    reducers: {
       
        searchVehicle:(state,action:PayloadAction<{search:string}>)=>{
            const { search } = action.payload;
             if (search.trim() === "") {
               state.vehicles = state.searchData;
             } else {
               const result = state.searchData.filter((item) =>
                 item.vehicleName.toLowerCase().includes(search.toLowerCase())
               );
               state.vehicles = result;
             }
               } 
    },
    extraReducers: (builder) => {
        builder.addCase(getAllVehicles.pending, (state) => {
            state.vehicleLoading = true
        })
            .addCase(getAllVehicles.fulfilled, (state, action) => {
                state.vehicles = action.payload;
                state.searchData = action.payload;
                state.vehicleLoading = false;
            })
            .addCase(getAllVehicles.rejected, (state) => {
                state.vehicleLoading = false
            })
    }
})
export const { reducer: VehicleReducer } = vehicleSlice;
export const{searchVehicle} = vehicleSlice.actions;