import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { vehicleDetails } from "./VehicleSlice";

export const getAllVehicles=createAsyncThunk<vehicleDetails[],void>(
"getAllVehicles",
async(_,{rejectWithValue})=>{
    try {
        const response=await axios.get("http://localhost:3000/vehicles")
        console.log(response.data)
        return response.data;
    } catch (error) {
        return rejectWithValue(error);
    }
}
)